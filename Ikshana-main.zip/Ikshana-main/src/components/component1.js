import React from 'react'

import './component1.css'

const Component1 = (props) => {
  return <div className="component1-container"></div>
}

export default Component1
